export const JWT_SECRET = process.env.JWT_SECRET ?? "kirat123";
export const WORKER_JWT_SECRET = JWT_SECRET + "worker";

export const TOTAL_DECIMALS = 1000_000;

// 1/1000_000_000_000_000_000